 // Function to handle the button click event
 function openBed() {
   window.location.href = 'bed.html';
 }

 function openPillow() {
   window.location.href = 'pillow.html';
 }

 function openSofa() {
   window.location.href = 'sofa.html';
 }

 
 function openRepair() {
   window.location.href = 'repair.html';
 }

 function openRent() {
   window.location.href = 'rent.html';
 }

 function openFurniture() {
  window.location.href = 'furniture.html';
}


// JavaScript to toggle the navbar on click
document.getElementById('hamburger-icon').addEventListener('click', function() {
  var navbar = document.querySelector('.navbar');
  navbar.classList.toggle('active');
});



