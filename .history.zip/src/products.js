// Toggle the mobile menu when the hamburger icon is clicked
document.getElementById('hamburger').addEventListener('click', function() {
    const menu = document.getElementById('menu');
    menu.classList.toggle('active');
});
